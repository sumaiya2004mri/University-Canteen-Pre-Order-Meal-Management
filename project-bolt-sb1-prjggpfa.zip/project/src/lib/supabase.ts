import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type MenuItem = {
  id: string;
  name: string;
  description: string | null;
  price: number;
  category: string | null;
  is_available: boolean;
  image_url: string | null;
};

export type PickupSlot = {
  id: string;
  slot_time: string;
  is_active: boolean;
};

export type OrderStatus = 'Pending' | 'Preparing' | 'Ready for Pickup' | 'Completed' | 'Cancelled';

export type Order = {
  id: string;
  user_id: string | null;
  pickup_slot_id: string | null;
  order_status: OrderStatus;
  total_amount: number | null;
  created_at: string;
};

export type OrderItem = {
  id: string;
  order_id: string;
  menu_item_id: string | null;
  quantity: number;
  price: number | null;
};

/**
 * Structured mock data — used ONLY when the logged-in user has no rows in the
 * `users` table yet. Real database values always take priority; nothing here is
 * written back to the database.
 */
export const MOCK_STUDENT: StudentProfile = {
  id: 'demo-student',
  name: 'Ayesha Rahman',
  student_id: 'VU-2023-0148',
  department: 'Computer Science & Engineering',
  program: 'B.Sc. Engineering',
  email: 'ayesha.rahman@varendra.edu.bd',
};

export type StudentProfile = {
  id: string;
  name: string;
  student_id: string;
  department: string;
  program: string;
  email: string;
};

export const BDT_RATE = 117; // demo conversion from a USD-denominated database to Taka display

export function formatBDT(amount: number | null | undefined): string {
  if (amount == null) return '—';
  return `৳${Math.round(Number(amount)).toLocaleString('en-IN')}`;
}
