import { supabase, type StudentProfile } from '@/lib/supabase';

export type Role = 'student' | 'admin';

export type SessionUser = StudentProfile & {
  role: Role;
};

/**
 * Credential handling uses Supabase Auth (email + password). Roles are read
 * server-side from the existing `users` table — never from browser input.
 * The browser only ever learns the role of the signed-in account; it cannot
 * grant itself a role.
 */
export async function signIn(email: string, password: string): Promise<{ user: SessionUser | null; error: string | null }> {
  const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
  if (error) return { user: null, error: error.message };
  if (!data.user) return { user: null, error: 'Sign-in failed. Please try again.' };

  const profile = await fetchProfile(data.user.id, data.user.email ?? email.trim());
  if (!profile) {
    await supabase.auth.signOut();
    return { user: null, error: 'No CampusBites profile is linked to this account.' };
  }
  return { user: profile, error: null };
}

export async function signUp(input: {
  name: string;
  studentId: string;
  email: string;
  password: string;
  department: string;
}): Promise<{ error: string | null; needsEmailConfirm: boolean }> {
  const { data, error } = await supabase.auth.signUp({
    email: input.email.trim(),
    password: input.password,
    options: { emailRedirectTo: window.location.origin },
  });
  if (error) return { error: error.message, needsEmailConfirm: false };
  if (!data.user) return { error: 'Registration failed. Please try again.', needsEmailConfirm: false };

  // New accounts are always created as students; a role can only be granted
  // through a trusted administrative process, never from the browser.
  const { error: profileErr } = await supabase.from('users').insert({
    id: data.user.id,
    name: input.name.trim(),
    student_id: input.studentId.trim(),
    department: input.department,
    email: input.email.trim(),
    role: 'student',
  });
  if (profileErr) {
    return { error: `Account created but the student profile could not be saved: ${profileErr.message}`, needsEmailConfirm: false };
  }
  return { error: null, needsEmailConfirm: !data.session };
}

export async function fetchProfile(userId: string, email: string): Promise<SessionUser | null> {
  const { data, error } = await supabase
    .from('users')
    .select('id, name, student_id, department, program, email, role')
    .eq('id', userId)
    .maybeSingle();

  if (!error && data) {
    const row = data as {
      id: string;
      name: string | null;
      student_id: string | null;
      department: string | null;
      program: string | null;
      email: string | null;
      role: string | null;
    };
    return {
      id: row.id,
      name: row.name ?? email.split('@')[0],
      student_id: row.student_id ?? '—',
      department: row.department ?? '—',
      program: row.program ?? '—',
      email: row.email ?? email,
      role: row.role === 'admin' ? 'admin' : 'student',
    };
  }

  // Fallback: the account exists in auth but has no users row yet.
  return {
    id: userId,
    name: email.split('@')[0],
    student_id: '—',
    department: '—',
    program: '—',
    email,
    role: 'student',
  };
}

export async function getSession(): Promise<SessionUser | null> {
  const { data } = await supabase.auth.getSession();
  const user = data.session?.user;
  if (!user) return null;
  return fetchProfile(user.id, user.email ?? '');
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut();
}

export async function updatePassword(newPassword: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  return { error: error?.message ?? null };
}
