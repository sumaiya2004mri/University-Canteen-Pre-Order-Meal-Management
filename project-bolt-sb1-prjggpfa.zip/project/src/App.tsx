import { useCallback, useEffect, useMemo, useState } from 'react';
import DashboardShell from '@/components/DashboardShell';
import AdminShell from '@/components/AdminShell';
import DashboardPage from '@/pages/DashboardPage';
import MenuPage from '@/pages/MenuPage';
import CartPage from '@/pages/CartPage';
import OrdersTablePage, { type OrderWithItems } from '@/pages/OrdersTablePage';
import TrackingPage from '@/pages/TrackingPage';
import HistoryPage from '@/pages/HistoryPage';
import { ProfilePage, StudentInfoPage } from '@/pages/ProfilePages';
import NotificationsPage from '@/pages/NotificationsPage';
import { HelpPage, LogoutPage, SettingsPage } from '@/pages/ServicePages';
import AuthPage from '@/pages/AuthPage';
import AdminDashboard, { type AdminOrder } from '@/pages/AdminDashboard';
import AdminOrders, { AdminCategories, AdminMenu } from '@/pages/AdminOps';
import { AdminSlots, AdminStock, AdminReports } from '@/pages/AdminOps2';
import { AdminProfilePage, AdminSettingsPage } from '@/pages/AdminAccount';
import { CartProvider, useCart } from '@/context/CartContext';
import { fetchProfile, getSession, signOut, type SessionUser } from '@/lib/auth';
import {
  MOCK_STUDENT,
  supabase,
  type MenuItem,
  type Order,
  type OrderStatus,
  type PickupSlot,
} from '@/lib/supabase';
import type { AdminPage, AppNotification, Page } from '@/types';

const INITIAL_NOTIFICATIONS: AppNotification[] = [
  {
    id: 'n1',
    title: 'Order being prepared',
    body: 'The canteen has started preparing your order.',
    time: '5 minutes ago',
    read: false,
    kind: 'order',
  },
  {
    id: 'n2',
    title: 'Order ready for pickup',
    body: 'Please collect your order at the CampusBites counter.',
    time: '32 minutes ago',
    read: false,
    kind: 'order',
  },
  {
    id: 'n3',
    title: 'New items on the menu',
    body: 'Fresh juice and chocolate cake have been added to the menu.',
    time: 'Today, 9:12 AM',
    read: false,
    kind: 'menu',
  },
  {
    id: 'n4',
    title: 'Previous order completed',
    body: 'Thanks for dining with CampusBites. See you again!',
    time: 'Yesterday, 1:45 PM',
    read: true,
    kind: 'order',
  },
];

type OrderItemRow = { id: string; order_id: string; quantity: number | null; menu_items: { name: string } | null };
function CampusBitesApp() {
  const [session, setSession] = useState<SessionUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [page, setPage] = useState<Page>('dashboard');
  const [adminPage, setAdminPage] = useState<AdminPage>('dashboard');
  const [student, setStudent] = useState<SessionUser | null>(null);

  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [loadingMenu, setLoadingMenu] = useState(true);
  const [menuError, setMenuError] = useState<string | null>(null);

  const [slots, setSlots] = useState<PickupSlot[]>([]);
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(true);
  const [ordersError, setOrdersError] = useState<string | null>(null);

  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [search, setSearch] = useState('');
  const { lines: cartLines, total: cartTotal, clear: clearCart } = useCart();

  useEffect(() => {
    async function init() {
      const user = await getSession();
      setSession(user);
      setStudent(user);
      setAuthLoading(false);
    }
    init();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event) => {
      (async () => {
        if (event === 'SIGNED_OUT') {
          setSession(null);
          setStudent(null);
        } else if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
          const user = await getSession();
          setSession(user);
          setStudent(user);
        }
      })();
    });
    return () => subscription.unsubscribe();
  }, []);

  const loadMenu = useCallback(async () => {
    setLoadingMenu(true);
    setMenuError(null);
    const { data, error } = await supabase
      .from('menu_items')
      .select('id, name, description, price, category, is_available, image_url, stock_quantity, created_at, updated_at');
    if (error) {
      // stock/created columns may not exist in every schema — retry without them
      const fallback = await supabase
        .from('menu_items')
        .select('id, name, description, price, category, is_available, image_url');
      if (fallback.error) {
        setMenuError(fallback.error.message);
        setMenuItems([]);
      } else {
        setMenuItems((fallback.data as unknown as MenuItem[]) ?? []);
      }
    } else {
      setMenuItems((data as unknown as MenuItem[]) ?? []);
    }
    setLoadingMenu(false);
  }, []);

  const loadOrders = useCallback(async () => {
    setLoadingOrders(true);
    setOrdersError(null);
    try {
      const [ordersRes, itemsRes, slotsRes] = await Promise.all([
        supabase
          .from('orders')
          .select('id, user_id, pickup_slot_id, order_status, total_amount, created_at')
          .order('created_at', { ascending: false }),
        supabase.from('order_items').select('id, order_id, quantity, price, menu_items(name)'),
        supabase.from('pickup_slots').select('id, slot_time, is_active').order('slot_time', { ascending: true }),
      ]);
      if (ordersRes.error) throw ordersRes.error;
      if (itemsRes.error) throw itemsRes.error;
      if (!slotsRes.error) setSlots((slotsRes.data as unknown as PickupSlot[]) ?? []);

      const allItems = (itemsRes.data as unknown as OrderItemRow[]) ?? [];
      setOrders(
        ((ordersRes.data as Order[]) ?? []).map((o) => ({
          ...o,
          items: allItems
            .filter((it) => it.order_id === o.id)
            .map((it) => ({
              name: it.menu_items?.name ?? 'Unknown item',
              quantity: it.quantity ?? 0,
            })),
        })),
      );
    } catch (e) {
      setOrdersError(e instanceof Error ? e.message : 'Failed to load orders.');
      setOrders([]);
    } finally {
      setLoadingOrders(false);
    }
  }, []);

  useEffect(() => {
    if (!session) return;
    loadMenu();
    loadOrders();
  }, [session, loadMenu, loadOrders]);

  const slotLabel = useCallback(
    (slotId: string | null) => {
      if (!slotId) return 'No slot';
      const slot = slots.find((s) => s.id === slotId);
      return slot
        ? new Date(slot.slot_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : 'No slot';
    },
    [slots],
  );

  const userDirectory = useMemo(() => {
    // Student names for order rows; guarded read — falls back gracefully if RLS restricts it
    return new Map<string, { name: string; studentId: string }>();
  }, []);

  const studentName = useCallback(
    (userId: string | null) => userDirectory.get(userId ?? '')?.name ?? (userId === student?.id ? student.name : 'Student'),
    [userDirectory, student],
  );
  const studentIdLabel = useCallback(
    (userId: string | null) => userDirectory.get(userId ?? '')?.studentId ?? (userId === student?.id ? student.student_id : '—'),
    [userDirectory, student],
  );

  const placeOrder = useCallback(
    async (
      slotId: string,
      total: number,
      lines: { menu_item_id: string; quantity: number; price: number }[],
    ): Promise<{ ok: boolean; message: string }> => {
      if (!student) return { ok: false, message: 'Please sign in to place an order.' };
      try {
        const { data: order, error: orderErr } = await supabase
          .from('orders')
          .insert({ user_id: student.id, pickup_slot_id: slotId, order_status: 'Pending', total_amount: total })
          .select('id')
          .maybeSingle();
        if (orderErr) throw orderErr;
        if (!order) throw new Error('Order could not be created');

        const { error: itemsErr } = await supabase
          .from('order_items')
          .insert(lines.map((l) => ({ order_id: order.id, menu_item_id: l.menu_item_id, quantity: l.quantity, price: l.price })));
        if (itemsErr) throw itemsErr;

        clearCart();
        loadOrders();
        setNotifications((prev) => [
          {
            id: `order-${order.id}`,
            title: 'Order placed',
            body: 'Your pre-order has been sent to the canteen.',
            time: 'Just now',
            read: false,
            kind: 'order',
          },
          ...prev,
        ]);
        return { ok: true, message: 'Order placed successfully. Your food will be ready at your pickup slot.' };
      } catch (e) {
        return { ok: false, message: e instanceof Error ? e.message : 'Something went wrong placing your order.' };
      }
    },
    [student, clearCart, loadOrders],
  );

  const updateOrderStatus = useCallback(
    async (orderId: string, status: OrderStatus): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can update order statuses.' };
      const { error } = await supabase.from('orders').update({ order_status: status }).eq('id', orderId);
      if (error) return { ok: false, message: `Failed to update status: ${error.message}` };
      setOrders((prev) => prev.map((o) => (o.id === orderId ? { ...o, order_status: status } : o)));
      return { ok: true, message: `Order #${orderId.slice(0, 8)} marked as ${status}.` };
    },
    [student],
  );

  const saveMenuItem = useCallback(
    async (item: Partial<MenuItem> & { id?: string; stock_quantity?: number | null }): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can edit the menu.' };
      const payload: Record<string, unknown> = {
        name: item.name,
        description: item.description,
        category: item.category,
        price: item.price,
        is_available: item.is_available,
      };
      if (item.stock_quantity != null) payload.stock_quantity = item.stock_quantity;

      const { error } = item.id
        ? await supabase.from('menu_items').update(payload).eq('id', item.id)
        : await supabase.from('menu_items').insert(payload);
      if (error) return { ok: false, message: error.message };
      await loadMenu();
      return { ok: true, message: item.id ? 'Menu item updated.' : 'Menu item created.' };
    },
    [student, loadMenu],
  );

  const deleteMenuItem = useCallback(
    async (item: MenuItem): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can delete menu items.' };
      // Prefer deactivation when the item appears in existing orders, to preserve order history
      const { data: used } = await supabase.from('order_items').select('id').eq('menu_item_id', item.id).limit(1);
      if (used && used.length > 0) {
        const { error } = await supabase.from('menu_items').update({ is_available: false }).eq('id', item.id);
        if (error) return { ok: false, message: error.message };
        await loadMenu();
        return { ok: true, message: `"${item.name}" appears in past orders, so it was marked unavailable instead of deleted.` };
      }
      const { error } = await supabase.from('menu_items').delete().eq('id', item.id);
      if (error) return { ok: false, message: error.message };
      await loadMenu();
      return { ok: true, message: `"${item.name}" deleted.` };
    },
    [student, loadMenu],
  );

  const updateStock = useCallback(
    async (item: MenuItem, newStock: number): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can change stock.' };
      if (!Number.isFinite(newStock) || newStock < 0) return { ok: false, message: 'Stock must be zero or more.' };
      const { error } = await supabase.from('menu_items').update({ stock_quantity: newStock }).eq('id', item.id);
      if (error) {
        return { ok: false, message: 'Stock updates are not available on this database schema (missing stock column).' };
      }
      await loadMenu();
      return { ok: true, message: `"${item.name}" stock set to ${newStock}.` };
    },
    [student, loadMenu],
  );

  const createSlot = useCallback(
    async (slotTime: string): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can manage slots.' };
      const { error } = await supabase.from('pickup_slots').insert({ slot_time: new Date(slotTime).toISOString(), is_active: true });
      if (error) return { ok: false, message: error.message };
      await loadOrders();
      return { ok: true, message: 'Pickup slot created.' };
    },
    [student, loadOrders],
  );

  const toggleSlot = useCallback(
    async (slot: PickupSlot): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can manage slots.' };
      const { error } = await supabase.from('pickup_slots').update({ is_active: !slot.is_active }).eq('id', slot.id);
      if (error) return { ok: false, message: error.message };
      await loadOrders();
      return { ok: true, message: `Slot ${slot.is_active ? 'disabled' : 'enabled'}.` };
    },
    [student, loadOrders],
  );

  const saveCategory = useCallback(
    async (newName: string, originalName: string | null): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can manage categories.' };
      if (!newName) return { ok: false, message: 'Category name cannot be empty.' };
      const { error } = originalName
        ? await supabase.from('menu_items').update({ category: newName }).eq('category', originalName)
        : await supabase.from('menu_items').update({ category: newName }).eq('category', newName);
      if (error) return { ok: false, message: error.message };
      await loadMenu();
      return originalName
        ? { ok: true, message: `Category renamed to "${newName}".` }
        : { ok: false, message: 'New categories appear automatically once a menu item uses them. Set the category on a menu item to create it.' };
    },
    [student, loadMenu],
  );

  const deleteCategory = useCallback(
    async (name: string): Promise<{ ok: boolean; message: string }> => {
      if (student?.role !== 'admin') return { ok: false, message: 'Only administrators can manage categories.' };
      const { error } = await supabase.from('menu_items').update({ category: null }).eq('category', name);
      if (error) return { ok: false, message: error.message };
      await loadMenu();
      return { ok: true, message: `Category "${name}" removed from all items.` };
    },
    [student, loadMenu],
  );

  const categories = useMemo(() => {
    const map = new Map<string, number>();
    for (const i of menuItems) {
      const c = i.category ?? 'Uncategorized';
      map.set(c, (map.get(c) ?? 0) + 1);
    }
    return Array.from(map.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [menuItems]);

  const handleOrderPlaced = useCallback(
    (orderId: string) => {
      loadOrders();
      setNotifications((prev) => [
        {
          id: `order-${orderId}`,
          title: 'Order placed',
          body: 'Your pre-order has been sent to the canteen.',
          time: 'Just now',
          read: false,
          kind: 'order',
        },
        ...prev,
      ]);
    },
    [loadOrders],
  );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const navigate = useCallback((p: Page) => {
    if (p === 'logout') {
      signOut();
      return;
    }
    setPage(p);
    window.scrollTo({ top: 0 });
  }, []);

  const adminNavigate = useCallback((p: AdminPage) => {
    if (p === 'logout') {
      signOut();
      return;
    }
    setAdminPage(p);
    window.scrollTo({ top: 0 });
  }, []);

  const filteredOrders = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return orders;
    return orders.filter(
      (o) =>
        o.id.slice(0, 8).toLowerCase().includes(q) ||
        o.order_status.toLowerCase().includes(q) ||
        o.items.some((it) => it.name.toLowerCase().includes(q)),
    );
  }, [orders, search]);

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-brand-ivory">
        <div className="animate-pulse text-sm font-semibold text-brand-gray">Loading CampusBites…</div>
      </div>
    );
  }

  if (!session) {
    return <AuthPage onSignedIn={() => { /* onAuthStateChange picks up the session */ }} />;
  }

  // Students get the student portal; admins get the admin console. The role
  // comes from the server-side profile, never from browser input.
  if (student?.role !== 'admin') {
    return (
      <>
        <DashboardShell
          page={page}
          onNavigate={navigate}
          student={student ?? MOCK_STUDENT_WITH_ID(student)}
          unreadCount={unreadCount}
          onLogout={() => signOut()}
          cartCount={cartLines.reduce((s, l) => s + l.quantity, 0)}
          search={search}
          onSearch={(v) => {
            setSearch(v);
            if (v) setPage((p) => (['orders', 'history', 'menu'].includes(p) ? p : 'orders'));
          }}
        >
          {page === 'dashboard' && (
            <DashboardPage
              student={student ?? MOCK_STUDENT_WITH_ID(student)}
              menuItems={menuItems}
              loadingMenu={loadingMenu}
              orders={orders.filter((o) => o.user_id === student?.id)}
              loadingOrders={loadingOrders}
              slotLabel={slotLabel}
              onNavigate={navigate}
              notifications={notifications}
            />
          )}
          {page === 'menu' && <MenuPage items={menuItems} loading={loadingMenu} error={menuError} />}
          {page === 'cart' && <CartPage slots={slots} onNavigate={navigate} placeOrder={placeOrder} />}
          {page === 'orders' && (
            <OrdersTablePage
              orders={searchOrders(orders.filter((o) => o.user_id === student?.id), search)}
              loading={loadingOrders}
              slotLabel={slotLabel}
              onNavigate={navigate}
              showSearch
              search={search}
              onSearch={setSearch}
            />
          )}
          {page === 'tracking' && (
            <TrackingPage
              orders={search.trim() ? searchOrders(orders.filter((o) => o.user_id === student?.id), search) : orders.filter((o) => o.user_id === student?.id)}
              loading={loadingOrders}
              slotLabel={slotLabel}
            />
          )}
          {page === 'history' && <HistoryPage orders={orders.filter((o) => o.user_id === student?.id)} loading={loadingOrders} slotLabel={slotLabel} />}
          {page === 'profile' && <ProfilePage student={student ?? MOCK_STUDENT_WITH_ID(student)} />}
          {page === 'student-info' && <StudentInfoPage student={student ?? MOCK_STUDENT_WITH_ID(student)} />}
          {page === 'notifications' && (
            <NotificationsPage
              notifications={notifications}
              onMarkAllRead={() => setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))}
              onMarkRead={(id) => setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))}
            />
          )}
          {page === 'help' && <HelpPage />}
          {page === 'settings' && <SettingsPage student={student ?? MOCK_STUDENT_WITH_ID(student)} />}
          {page === 'staff' && <StaffView slots={slots} />}
          {page === 'logout' && <LogoutPage onConfirm={() => signOut()} />}
        </DashboardShell>
      </>
    );
  }

  return (
    <AdminShell page={adminPage} onNavigate={adminNavigate} admin={student} onLogout={() => signOut()}>
      {adminPage === 'dashboard' && (
        <AdminDashboard
          orders={orders}
          menuItems={menuItems}
          slots={slots}
          loading={loadingOrders || loadingMenu}
          error={ordersError}
          onRetry={loadOrders}
          slotLabel={slotLabel}
        />
      )}
      {adminPage === 'orders' && (
        <AdminOrders
          orders={orders}
          loading={loadingOrders}
          slotLabel={slotLabel}
          onUpdateStatus={updateOrderStatus}
          studentName={studentName}
          studentId={studentIdLabel}
        />
      )}
      {adminPage === 'menu' && (
        <AdminMenu items={menuItems} loading={loadingMenu} onSave={saveMenuItem} onDelete={deleteMenuItem} categories={categories.map((c) => c.name)} />
      )}
      {adminPage === 'categories' && (
        <AdminCategories
          categories={categories}
          loading={loadingMenu}
          onSave={saveCategory}
          onDelete={(name) => deleteCategory(name)}
        />
      )}
      {adminPage === 'stock' && <AdminStock items={menuItems} loading={loadingMenu} onUpdateStock={updateStock} />}
      {adminPage === 'slots' && (
        <AdminSlots
          slots={slots.map((s) => ({
            ...s,
            reserved: orders.filter((o) => o.pickup_slot_id === s.id && o.order_status !== 'Cancelled').length,
          }))}
          loading={loadingOrders}
          onCreate={createSlot}
          onToggle={toggleSlot}
        />
      )}
      {(adminPage === 'reports-sales' || adminPage === 'reports-orders' || adminPage === 'reports-inventory') && (
        <AdminReports orders={orders} menuItems={menuItems} loading={loadingOrders} />
      )}
      {adminPage === 'profile' && <AdminProfilePage admin={student} />}
      {adminPage === 'settings' && <AdminSettingsPage admin={student} />}
    </AdminShell>
  );
}

// Renders the demo profile only while the signed-in account has no profile row
function MOCK_STUDENT_WITH_ID(student: SessionUser | null) {
  return student ? { ...MOCK_STUDENT, ...student, id: student.id } : MOCK_STUDENT;
}

function searchOrders(list: AdminOrder[], search: string): AdminOrder[] {
  const q = search.trim().toLowerCase();
  if (!q) return list;
  return list.filter(
    (o) =>
      o.id.slice(0, 8).toLowerCase().includes(q) ||
      o.order_status.toLowerCase().includes(q) ||
      o.items.some((it) => it.name.toLowerCase().includes(q)),
  );
}

function StudentAccessDenied({ student, onSignedIn }: { student: SessionUser | null; onSignedIn: () => void }) {
  return (
    <div className="rounded-2xl border border-brand-border bg-white p-8 shadow-sm">
      <p className="text-lg font-bold text-brand-black">Admin Access Required</p>
      <p className="mt-2 text-sm text-brand-gray">
        You are signed in as a student. The admin console is only available to canteen administrators. If you
        believe you should have admin access, contact the canteen manager.
      </p>
      <button
        onClick={() => {
          onSignedIn();
        }}
        className="focus-ring mt-5 rounded-xl bg-brand-primary px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-dark"
      >
        Continue as {student?.name ?? 'Student'}
      </button>
    </div>
  );
}

export default function AppRoot() {
  return (
    <CartProvider>
      <CampusBitesApp />
    </CartProvider>
  );
}
